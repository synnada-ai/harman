def first_function_harman():
    print("first function of composite ML library harman")